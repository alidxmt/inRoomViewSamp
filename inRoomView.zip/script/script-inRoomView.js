

var inRoomviewDiv = document.getElementById("room-div");

var paintingImage = document.getElementById("painting-image");

paintingImage.width=paintingImage.alt.split("|")[0].split("*")[0]*(window.innerHeight/919)*1.52;

paintingImage.style.top = inRoomviewDiv.offsetHeight/4-paintingImage.offsetHeight/2+"px";
paintingImage.style.left = inRoomviewDiv.offsetWidth/2-paintingImage.offsetWidth/2+"px";


function changeImage(_address,_info){

    paintingImage.src=_address;
    paintingImage.alt=_info;
    paintingImage.width=_info.split("|")[0].split("*")[0]*152;
    paintingImage.width=paintingImage.width/(window.innerWidth/900);
    paintingImage.style.top = inRoomviewDiv.offsetHeight/4-paintingImage.offsetHeight/2+"px";
    paintingImage.style.left = inRoomviewDiv.offsetWidth/2-paintingImage.offsetWidth/2+"px";
    
}

//changeImage("images/sample-painting-persian.jpg","2.5*1.2|Ahmad");




